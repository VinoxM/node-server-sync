export default {
    rssSubscribe: {
        nameJP: "name_jp",
        startTime: "start_time",
        isShort: "is_short",
        animeType: "anime_type",
        originType: "origin_type",
        typeTag: "type_tag"
    },
    rssResult: {
        upDate: 'up_date',
        pubDate: 'pub_date'
    }
}