export default {
    DB_WEB_PENDANT: "webPendant"
}