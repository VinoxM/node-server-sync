export default {
    TYPE_JSON: "application/json",
    TYPE_FORM: "application/x-www-form-urlencoded",
    TYPE_TEXT: "text/plain",
    TYPE_MULTIPART: "multipart/form-data"
}