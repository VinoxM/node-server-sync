export default {
    SEASON: 'season',
    ID: 'id',
    PID: 'pid',
    NAME: 'name'
}