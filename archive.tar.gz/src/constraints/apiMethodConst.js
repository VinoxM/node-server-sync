export default {
    GET: 'GET',
    POST: 'POST'
}