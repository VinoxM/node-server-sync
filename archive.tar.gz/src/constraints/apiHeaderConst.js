export default {
    SECRET: 'secret'
}